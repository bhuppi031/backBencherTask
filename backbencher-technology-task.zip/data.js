const users = [];
const tasks = [];

module.exports = { users, tasks };
